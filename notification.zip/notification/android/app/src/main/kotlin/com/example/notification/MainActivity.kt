package com.example.notification

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
